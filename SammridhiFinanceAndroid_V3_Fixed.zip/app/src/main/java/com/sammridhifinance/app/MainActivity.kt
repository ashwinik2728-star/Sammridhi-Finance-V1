package com.sammridhifinance.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Lead(val name:String,val loan:String,val amount:String,val status:String)

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SammridhiApp() }
    }
}

@Composable
fun SammridhiApp() {
    var screen by remember { mutableStateOf("Dashboard") }
    var loggedIn by remember { mutableStateOf(false) }
    if (!loggedIn) LoginScreen { loggedIn=true } else {
        MaterialTheme {
            Scaffold(
                bottomBar = {
                    NavigationBar {
                        listOf("Dashboard" to Icons.Default.Home, "Leads" to Icons.Default.Person, "Products" to Icons.Default.AccountBalance, "Reports" to Icons.Default.Assessment).forEach {
                            NavigationBarItem(selected=screen==it.first,onClick={screen=it.first},icon={Icon(it.second,null)},label={Text(it.first)})
                        }
                    }
                }
            ) { p ->
                Box(Modifier.padding(p).fillMaxSize()) {
                    when(screen) {
                        "Leads" -> LeadsScreen()
                        "Products" -> ProductsScreen()
                        "Reports" -> ReportsScreen()
                        else -> DashboardScreen { screen="Leads" }
                    }
                }
            }
        }
    }
}

@Composable
fun LoginScreen(onLogin:()->Unit) {
    Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
        Text("Sammridhi Finance",fontSize=30.sp,fontWeight=FontWeight.Bold)
        Text("Lead to Disbursal",fontSize=16.sp)
        Spacer(Modifier.height(32.dp))
        OutlinedTextField("",{},label={Text("Mobile Number")},modifier=Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField("",{},label={Text("Password / OTP")},modifier=Modifier.fillMaxWidth())
        Spacer(Modifier.height(20.dp))
        Button(onClick=onLogin,modifier=Modifier.fillMaxWidth()) { Text("Login") }
    }
}

@Composable
fun DashboardScreen(openLeads:()->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp)) {
        item {
            Text("Dashboard",fontSize=28.sp,fontWeight=FontWeight.Bold)
            Text("Sammridhi Finance",fontSize=16.sp)
            Spacer(Modifier.height(20.dp))
        }
        item { SummaryCard("Total Leads","128"); Spacer(Modifier.height(12.dp)) }
        item { SummaryCard("Applications","74"); Spacer(Modifier.height(12.dp)) }
        item { SummaryCard("Sanctioned","42"); Spacer(Modifier.height(12.dp)) }
        item { SummaryCard("Disbursed","31"); Spacer(Modifier.height(20.dp)) }
        item { Button(onClick=openLeads,modifier=Modifier.fillMaxWidth()) { Text("Manage Leads") } }
    }
}

@Composable
fun SummaryCard(title:String,value:String) {
    Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(20.dp),horizontalArrangement=Arrangement.SpaceBetween) {
        Text(title); Text(value,fontWeight=FontWeight.Bold,fontSize=22.sp)
    }}
}

@Composable
fun LeadsScreen() {
    val leads=listOf(
        Lead("Raj Kumar","Personal Loan","₹3,00,000","Verification"),
        Lead("Priya Devi","Business Loan","₹8,00,000","Sanctioned"),
        Lead("Amit Singh","Home Loan","₹25,00,000","Documents"),
        Lead("Neha Sharma","Vehicle Loan","₹6,50,000","Disbursed")
    )
    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
        item {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                Text("Leads",fontSize=28.sp,fontWeight=FontWeight.Bold)
                Button(onClick={}) { Text("+ New Lead") }
            }
            Spacer(Modifier.height(12.dp))
        }
        items(leads) { l ->
            Card(Modifier.fillMaxWidth().padding(vertical=6.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(l.name,fontWeight=FontWeight.Bold,fontSize=18.sp)
                    Text(l.loan)
                    Text(l.amount)
                    Text("Status: ${l.status}")
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick={}) { Text("Open Application") }
                }
            }
        }
    }
}

@Composable
fun ProductsScreen() {
    val products=listOf("Personal Loan","Business Loan","Home Loan","Loan Against Property","Vehicle Loan","Education Loan","Gold Loan","MSME / Working Capital")
    LazyColumn(Modifier.fillMaxSize().padding(20.dp)) {
        item { Text("Loan Products",fontSize=28.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.height(16.dp)) }
        items(products) { p -> Card(Modifier.fillMaxWidth().padding(vertical=5.dp)) { ListItem(headlineContent={Text(p)},leadingContent={Icon(Icons.Default.AccountBalance,null)}) } }
    }
}

@Composable
fun ReportsScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Reports",fontSize=28.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Text("Lead → Login/Application → KYC → Verification → Sanction → Disbursal")
        Spacer(Modifier.height(20.dp))
        SummaryCard("Monthly Disbursal","₹1.42 Cr")
        Spacer(Modifier.height(12.dp))
        SummaryCard("Pending Applications","32")
    }
}
