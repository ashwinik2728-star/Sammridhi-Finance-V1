# Sammridhi Finance Android App

Lead-to-disbursal Android starter built with Kotlin + Jetpack Compose.

## Included
- Login screen
- Dashboard
- Lead management
- All loan products
- New lead form
- KYC/document checklist
- Application status
- Verification
- Sanction
- Disbursal
- Reports
- Bottom navigation

## Run
Open this folder in Android Studio (Ladybug or newer), let Gradle sync, then run on an Android 8.0+ device/emulator.

This V1 is a UI/workflow prototype. It does not yet connect to a live backend, OTP provider, credit bureau, bank APIs, or production document storage.
