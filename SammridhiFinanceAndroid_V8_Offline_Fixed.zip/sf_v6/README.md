# Sammridhi Finance V8

Branded Android finance workflow prototype.

Tagline: **Built for Growth. Backed by Trust.**

Includes refreshed visual design across login, dashboard, leads, loan products, new lead, KYC, verification, sanction, disbursal, reports and profile screens.

This is an offline prototype. Real OTP, KYC integrations, credit bureau checks, backend storage, role-based access, audit logs and real disbursal integrations must be connected before production use.
