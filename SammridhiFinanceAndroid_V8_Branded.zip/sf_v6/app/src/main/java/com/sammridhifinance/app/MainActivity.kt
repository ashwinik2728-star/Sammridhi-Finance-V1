package com.sammridhifinance.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val BrandPurple = Color(0xFF43249A)
private val BrandPurple2 = Color(0xFF6B45C8)
private val BrandNavy = Color(0xFF152A58)
private val BrandGold = Color(0xFFD9A62E)
private val BrandGreen = Color(0xFF2C9A70)
private val PageBg = Color(0xFFF5F7FC)
private val CardWhite = Color.White
private const val TAGLINE = "Built for Growth. Backed by Trust."

private data class Lead(val id: Int, val name: String, val mobile: String, val loan: String, val amount: String, var status: String)

private val loanProducts = listOf(
    "Personal Loan", "Business Loan", "Home Loan", "Loan Against Property",
    "Vehicle Loan", "Education Loan", "Gold Loan", "MSME / Working Capital"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SammridhiApp() }
    }
}

@Composable
fun SammridhiApp() {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = BrandPurple,
            secondary = BrandGold,
            background = PageBg,
            surface = CardWhite,
            onPrimary = Color.White,
            onBackground = BrandNavy,
            onSurface = BrandNavy
        )
    ) {
        var loggedIn by remember { mutableStateOf(false) }
        var screen by remember { mutableStateOf("Dashboard") }
        var selectedLead by remember { mutableStateOf<Int?>(null) }
        var nextLeadId by remember { mutableIntStateOf(5) }
        val leads = remember {
            mutableStateListOf(
                Lead(1, "Raj Kumar", "9876543210", "Personal Loan", "₹3,00,000", "Verification"),
                Lead(2, "Priya Devi", "9876543211", "Business Loan", "₹8,00,000", "Sanctioned"),
                Lead(3, "Amit Singh", "9876543212", "Home Loan", "₹25,00,000", "Documents"),
                Lead(4, "Neha Sharma", "9876543213", "Vehicle Loan", "₹6,50,000", "Disbursed")
            )
        }

        if (!loggedIn) LoginScreen { loggedIn = true }
        else Scaffold(
            containerColor = PageBg,
            topBar = { BrandTopBar(screen) { screen = "Profile" } },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Dashboard" to Icons.Default.Home, "Leads" to Icons.Default.People, "Products" to Icons.Default.AccountBalance, "Reports" to Icons.Default.Assessment).forEach { (name, icon) ->
                        NavigationBarItem(
                            selected = screen == name,
                            onClick = { screen = name; selectedLead = null },
                            icon = { Icon(icon, null) },
                            label = { Text(name, fontSize = 11.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (screen) {
                    "Dashboard" -> DashboardScreen(leads, { screen = "NewLead" }, { screen = "Leads" }, { screen = "Products" }, { screen = "Reports" })
                    "Leads" -> LeadsScreen(leads, { screen = "NewLead" }) { id -> selectedLead = id; screen = "Application" }
                    "Products" -> ProductsScreen { screen = "NewLead" }
                    "Reports" -> ReportsScreen(leads)
                    "NewLead" -> NewLeadScreen({ screen = "Dashboard" }) { name, mobile, loan, amount ->
                        leads.add(Lead(nextLeadId++, name, mobile, loan, amount, "New Lead")); screen = "Leads"
                    }
                    "Application" -> leads.firstOrNull { it.id == selectedLead }?.let { lead -> ApplicationScreen(lead, { screen = "Leads" }) { screen = "KYC" } } ?: run { screen = "Leads" }
                    "KYC" -> KycScreen({ screen = "Application" }) { screen = "Verification" }
                    "Verification" -> VerificationScreen({ screen = "KYC" }) { screen = "Sanction" }
                    "Sanction" -> SanctionScreen({ screen = "Verification" }) { screen = "Disbursal" }
                    "Disbursal" -> DisbursalScreen { screen = "Dashboard" }
                    "Profile" -> ProfileScreen { loggedIn = false; screen = "Dashboard" }
                }
            }
        }
    }
}

@Composable
private fun BrandTopBar(screen: String, onProfile: () -> Unit) {
    Surface(color = BrandPurple, shadowElevation = 4.dp) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Sammridhi FINANCE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(screen, color = Color.White.copy(alpha = .82f), fontSize = 11.sp)
            }
            IconButton(onClick = onProfile) { Icon(Icons.Default.AccountCircle, "Profile", tint = Color.White) }
        }
    }
}

@Composable
private fun FinanceBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFFDFEFF), Color(0xFFEFF4FC))))) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            drawCircle(Color(0xFF6B45C8).copy(alpha = .055f), w * .34f, Offset(w * .94f, h * .12f))
            drawCircle(Color(0xFFD9A62E).copy(alpha = .07f), w * .22f, Offset(w * .06f, h * .72f))
            val wave = Path().apply {
                moveTo(0f, h * .88f); cubicTo(w * .25f, h * .80f, w * .55f, h * .94f, w, h * .83f); lineTo(w, h); lineTo(0f, h); close()
            }
            drawPath(wave, Brush.verticalGradient(listOf(BrandPurple.copy(alpha = .10f), BrandPurple.copy(alpha = .20f))))
            drawArc(BrandGold.copy(alpha = .65f), 185f, 170f, false, Offset(-w*.18f, h*.78f), Size(w*1.4f, h*.22f), style = Stroke(width = 6f, cap = StrokeCap.Round))
        }
        content()
    }
}

@Composable
fun LoginScreen(onLogin: () -> Unit) {
    var mobile by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }; var error by remember { mutableStateOf("") }
    FinanceBackground {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(42.dp))
            Box(Modifier.size(86.dp).clip(RoundedCornerShape(24.dp)).background(Color.White.copy(alpha = .92f)), contentAlignment = Alignment.Center) {
                Text("S", fontSize = 58.sp, fontWeight = FontWeight.Bold, color = BrandGold)
            }
            Spacer(Modifier.height(12.dp))
            Text("Sammridhi", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = BrandNavy)
            Text("FINANCE", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = BrandNavy, letterSpacing = 4.sp)
            Text(TAGLINE, color = BrandPurple, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(34.dp))
            Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .94f)), elevation = CardDefaults.cardElevation(8.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("Welcome Back", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = BrandNavy)
                    Text("Sign in to manage your loan journey", color = Color(0xFF6D7385), fontSize = 13.sp)
                    Spacer(Modifier.height(18.dp))
                    Field("Mobile Number", mobile, { mobile = it.filter(Char::isDigit).take(10); error = "" }, KeyboardType.Phone, Icons.Default.Phone)
                    Field("Password / OTP", password, { password = it; error = "" }, KeyboardType.Password, Icons.Default.Lock, true)
                    if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { if (mobile.length != 10) error = "Please enter a valid 10 digit mobile number" else if (password.isBlank()) error = "Please enter password / OTP" else onLogin() }, Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp)) {
                        Text("Login  →", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(18.dp)); Text(TAGLINE, color = BrandNavy.copy(alpha = .65f), fontSize = 12.sp)
            Spacer(Modifier.height(34.dp))
        }
    }
}

@Composable
fun DashboardScreen(leads: List<Lead>, onNewLead: () -> Unit, onLeads: () -> Unit, onProducts: () -> Unit, onReports: () -> Unit) {
    FinanceBackground {
        LazyColumn(Modifier.fillMaxSize().padding(18.dp)) {
            item {
                Text("Welcome Back", fontSize = 15.sp, color = Color(0xFF687087)); Text("Agent Dashboard", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = BrandNavy)
                Text(TAGLINE, fontSize = 12.sp, color = BrandPurple); Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricCard("Total Leads", leads.size.toString(), Icons.Default.People, Modifier.weight(1f)); MetricCard("Sanctioned", leads.count { it.status == "Sanctioned" || it.status == "Disbursed" }.toString(), Icons.Default.CheckCircle, Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp)); Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricCard("Disbursed", leads.count { it.status == "Disbursed" }.toString(), Icons.Default.CurrencyRupee, Modifier.weight(1f)); MetricCard("In Progress", leads.count { it.status != "Disbursed" }.toString(), Icons.Default.Schedule, Modifier.weight(1f))
                }
                Spacer(Modifier.height(22.dp)); Text("Quick Actions", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = BrandNavy); Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) { ActionCard("New Lead", Icons.Default.PersonAdd, onNewLead, Modifier.weight(1f)); ActionCard("My Leads", Icons.Default.People, onLeads, Modifier.weight(1f)); ActionCard("Loan Products", Icons.Default.AccountBalance, onProducts, Modifier.weight(1f)) }
                Spacer(Modifier.height(12.dp)); OutlinedButton(onClick = onReports, Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) { Text("View Reports") }
                Spacer(Modifier.height(24.dp)); BrandBanner()
            }
        }
    }
}

@Composable private fun BrandBanner() { Card(colors = CardDefaults.cardColors(containerColor = BrandPurple), shape = RoundedCornerShape(22.dp)) { Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Together We Build", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text("Stronger Futures", color = Color.White.copy(alpha=.85f)); Text(TAGLINE, color = BrandGold, fontSize = 11.sp) }; Icon(Icons.Default.TrendingUp, null, tint = BrandGold, modifier = Modifier.size(44.dp)) } } }

@Composable private fun MetricCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) { Card(modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha=.95f)), elevation = CardDefaults.cardElevation(3.dp)) { Column(Modifier.padding(15.dp)) { Icon(icon, null, tint = BrandPurple, modifier = Modifier.size(24.dp)); Spacer(Modifier.height(7.dp)); Text(value, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = BrandNavy); Text(title, fontSize = 12.sp, color = Color(0xFF6D7385)) } } }
@Composable private fun ActionCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, modifier: Modifier) { Card(modifier.clickable { onClick() }, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha=.96f))) { Column(Modifier.padding(11.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null, tint = BrandPurple); Spacer(Modifier.height(6.dp)); Text(title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = BrandNavy) } } }

@Composable fun LeadsScreen(leads: List<Lead>, onNewLead: () -> Unit, onOpen: (Int) -> Unit) { FinanceBackground { LazyColumn(Modifier.fillMaxSize().padding(16.dp)) { item { Row(verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Leads", fontSize=28.sp, fontWeight=FontWeight.Bold, color=BrandNavy); Text(TAGLINE, fontSize=11.sp, color=BrandPurple) }; Button(onClick=onNewLead, shape=RoundedCornerShape(14.dp)) { Text("+ New Lead") } }; Spacer(Modifier.height(14.dp)) }; items(leads, key={it.id}) { lead -> LeadCard(lead) { onOpen(lead.id) } } } } }
@Composable private fun LeadCard(lead: Lead, onOpen: () -> Unit) { Card(Modifier.fillMaxWidth().padding(vertical=5.dp).clickable{onOpen()}, shape=RoundedCornerShape(18.dp), colors=CardDefaults.cardColors(containerColor=Color.White.copy(alpha=.96f))) { Column(Modifier.padding(15.dp)) { Row(verticalAlignment=Alignment.CenterVertically) { Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(BrandPurple.copy(alpha=.10f)), contentAlignment=Alignment.Center) { Icon(Icons.Default.Person, null, tint=BrandPurple) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(lead.name, fontWeight=FontWeight.Bold, color=BrandNavy); Text(lead.mobile, fontSize=12.sp, color=Color.Gray) }; Text(lead.status, color=BrandPurple, fontSize=11.sp, fontWeight=FontWeight.Bold) }; Spacer(Modifier.height(10.dp)); Text(lead.loan, fontWeight=FontWeight.SemiBold); Text(lead.amount, color=BrandNavy, fontWeight=FontWeight.Bold); Spacer(Modifier.height(9.dp)); OutlinedButton(onClick=onOpen, Modifier.fillMaxWidth(), shape=RoundedCornerShape(13.dp)) { Text("Open Application  →") } } } }

@Composable fun ProductsScreen(onSelect: (String) -> Unit) { FinanceBackground { LazyColumn(Modifier.fillMaxSize().padding(18.dp)) { item { Text("Loan Products", fontSize=28.sp, fontWeight=FontWeight.Bold, color=BrandNavy); Text("Choose a product to create a lead", color=BrandPurple, fontSize=12.sp); Spacer(Modifier.height(16.dp)) }; items(loanProducts) { product -> Card(Modifier.fillMaxWidth().padding(vertical=5.dp).clickable{onSelect(product)}, shape=RoundedCornerShape(18.dp), colors=CardDefaults.cardColors(containerColor=Color.White.copy(alpha=.96f))) { ListItem(headlineContent={Text(product,fontWeight=FontWeight.Bold)}, supportingContent={Text("Start a new application")}, leadingContent={Icon(Icons.Default.AccountBalance,null,tint=BrandPurple)}, trailingContent={Icon(Icons.Default.ChevronRight,null,tint=BrandGold)}, colors=ListItemDefaults.colors(containerColor=Color.Transparent)) } } } } }

@Composable fun ReportsScreen(leads: List<Lead>) { FinanceBackground { LazyColumn(Modifier.fillMaxSize().padding(18.dp)) { item { Text("Reports", fontSize=28.sp, fontWeight=FontWeight.Bold, color=BrandNavy); Text(TAGLINE, fontSize=11.sp, color=BrandPurple); Spacer(Modifier.height(16.dp)); MetricCard("Total Leads", leads.size.toString(), Icons.Default.People, Modifier.fillMaxWidth()); Spacer(Modifier.height(9.dp)); MetricCard("Applications", leads.count{it.status!="New Lead"}.toString(), Icons.Default.Description, Modifier.fillMaxWidth()); Spacer(Modifier.height(9.dp)); MetricCard("Disbursed", leads.count{it.status=="Disbursed"}.toString(), Icons.Default.CurrencyRupee, Modifier.fillMaxWidth()); Spacer(Modifier.height(18.dp)); Card(shape=RoundedCornerShape(20.dp), colors=CardDefaults.cardColors(containerColor=Color.White.copy(alpha=.95f))) { Column(Modifier.padding(18.dp)) { Text("Workflow", fontWeight=FontWeight.Bold, fontSize=18.sp, color=BrandNavy); Spacer(Modifier.height(9.dp)); Text("Lead  →  Application  →  KYC  →  Verification  →  Sanction  →  Disbursal", color=Color(0xFF5E6577)); Spacer(Modifier.height(14.dp)); Text(TAGLINE, color=BrandPurple, fontSize=12.sp) } } } } } }

@Composable fun NewLeadScreen(onBack: () -> Unit, onSave: (String,String,String,String)->Unit) { var name by remember{mutableStateOf("")}; var mobile by remember{mutableStateOf("")}; var amount by remember{mutableStateOf("")}; var loan by remember{mutableStateOf(loanProducts.first())}; var error by remember{mutableStateOf("")}; FormScaffold("New Lead",onBack,"Customer & Loan Details") { Field("Full Name *",name,{name=it;error=""},icon=Icons.Default.Person); Field("Mobile Number *",mobile,{mobile=it.filter(Char::isDigit).take(10);error=""},KeyboardType.Phone,Icons.Default.Phone); Field("Loan Amount *",amount,{amount=it;error=""},KeyboardType.Number,Icons.Default.CurrencyRupee); Text("Loan Product",fontWeight=FontWeight.Bold,color=BrandNavy); loanProducts.forEach{p->Row(Modifier.fillMaxWidth().clickable{loan=p}.padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically){RadioButton(loan==p,{loan=p});Text(p)}}; if(error.isNotEmpty()) Text(error,color=MaterialTheme.colorScheme.error,fontSize=12.sp); Button(onClick={when{ name.isBlank()->error="Enter customer name";mobile.length!=10->error="Enter a valid 10 digit mobile number";amount.isBlank()->error="Enter loan amount";else->onSave(name,mobile,loan,"₹${amount.filter{it.isDigit()}}")}},Modifier.fillMaxWidth().height(52.dp),shape=RoundedCornerShape(15.dp)){Text("Save Lead  →",fontWeight=FontWeight.Bold)} } }

@Composable fun ApplicationScreen(lead: Lead,onBack:()->Unit,onKyc:()->Unit){FormScaffold("Application",onBack,"Application Overview"){SummaryCard("Customer",lead.name);SummaryCard("Mobile",lead.mobile);SummaryCard("Loan Type",lead.loan);SummaryCard("Amount",lead.amount);SummaryCard("Status",lead.status);Button(onClick=onKyc,Modifier.fillMaxWidth().height(52.dp),shape=RoundedCornerShape(15.dp)){Text("Continue to KYC  →",fontWeight=FontWeight.Bold)}}}
@Composable fun KycScreen(onBack:()->Unit,onNext:()->Unit){var aadhaar by remember{mutableStateOf("")};var pan by remember{mutableStateOf("")};var dob by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};FormScaffold("KYC Verification",onBack,"Personal Information"){Text("Step 1 of 4",color=BrandPurple,fontWeight=FontWeight.Bold);Field("Aadhaar Number *",aadhaar,{aadhaar=it.filter(Char::isDigit).take(12);error=""},KeyboardType.Number,Icons.Default.Badge);Field("PAN Number *",pan,{pan=it.uppercase().take(10);error=""},icon=Icons.Default.CreditCard);Field("Date of Birth *",dob,{dob=it;error=""},icon=Icons.Default.DateRange);Text("Upload Documents",fontSize=18.sp,fontWeight=FontWeight.Bold,color=BrandNavy);Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){OutlinedButton(onClick={},Modifier.weight(1f),shape=RoundedCornerShape(13.dp)){Icon(Icons.Default.UploadFile,null);Spacer(Modifier.width(5.dp));Text("Aadhaar")};OutlinedButton(onClick={},Modifier.weight(1f),shape=RoundedCornerShape(13.dp)){Icon(Icons.Default.UploadFile,null);Spacer(Modifier.width(5.dp));Text("PAN")}};if(error.isNotEmpty())Text(error,color=MaterialTheme.colorScheme.error,fontSize=12.sp);Spacer(Modifier.height(10.dp));Button(onClick={when{aadhaar.length!=12->error="Enter 12 digit Aadhaar number";pan.length!=10->error="Enter valid PAN number";dob.isBlank()->error="Enter date of birth";else->onNext()}},Modifier.fillMaxWidth().height(52.dp),shape=RoundedCornerShape(15.dp)){Text("Next: Verification  →",fontWeight=FontWeight.Bold)}}}
@Composable fun VerificationScreen(onBack:()->Unit,onNext:()->Unit){var a by remember{mutableStateOf(false)};var e by remember{mutableStateOf(false)};var d by remember{mutableStateOf(false)};var c by remember{mutableStateOf(false)};FormScaffold("Verification",onBack,"Verification Checklist"){Text("Step 2 of 4",color=BrandPurple,fontWeight=FontWeight.Bold);CheckRow("Address Verification",a){a=it};CheckRow("Employment Verification",e){e=it};CheckRow("Document Verification",d){d=it};CheckRow("Credit Bureau Check",c){c=it};Spacer(Modifier.height(10.dp));Button(onClick=onNext,enabled=a&&e&&d&&c,Modifier.fillMaxWidth().height(52.dp),shape=RoundedCornerShape(15.dp)){Text("Next: Sanction  →",fontWeight=FontWeight.Bold)}}}
@Composable fun SanctionScreen(onBack:()->Unit,onNext:()->Unit){var approved by remember{mutableStateOf(false)};FormScaffold("Sanction",onBack,"Credit Decision"){Text("Step 3 of 4",color=BrandPurple,fontWeight=FontWeight.Bold);Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(18.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(if(approved)Icons.Default.CheckCircle else Icons.Default.Schedule,null,tint=if(approved)BrandGreen:BrandGold,modifier=Modifier.size(50.dp));Text(if(approved)"Application Approved" else "Pending Review",fontWeight=FontWeight.Bold,fontSize=20.sp,color=BrandNavy);Text(TAGLINE,fontSize=11.sp,color=BrandPurple)}};Spacer(Modifier.height(14.dp));OutlinedButton(onClick={approved=true},Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Text("Approve Application")};Spacer(Modifier.height(10.dp));Button(onClick=onNext,enabled=approved,Modifier.fillMaxWidth().height(52.dp),shape=RoundedCornerShape(15.dp)){Text("Proceed to Disbursal  →",fontWeight=FontWeight.Bold)}}}
@Composable fun DisbursalScreen(onDone:()->Unit){var done by remember{mutableStateOf(false)};FormScaffold("Disbursal",onDone,"Final Funding Step"){Icon(if(done)Icons.Default.CheckCircle else Icons.Default.CurrencyRupee,null,tint=if(done)BrandGreen:BrandPurple,modifier=Modifier.size(64.dp).align(Alignment.CenterHorizontally));Text(if(done)"Disbursal Successful" else "Ready for Disbursal",fontSize=23.sp,fontWeight=FontWeight.Bold,color=BrandNavy,modifier=Modifier.align(Alignment.CenterHorizontally));Spacer(Modifier.height(10.dp));SummaryCard("Loan Amount","₹2,00,000");SummaryCard("Tenure","24 Months");SummaryCard("Interest Rate","12% p.a.");Spacer(Modifier.height(12.dp));Button(onClick={done=true},enabled=!done,Modifier.fillMaxWidth().height(52.dp),shape=RoundedCornerShape(15.dp)){Text(if(done)"Disbursed ✓" else "Confirm Disbursal",fontWeight=FontWeight.Bold)};if(done)Text("Amount has been marked as disbursed in this offline prototype.",color=BrandGreen,fontSize=12.sp);Spacer(Modifier.height(10.dp));OutlinedButton(onClick=onDone,Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Text("Back to Dashboard")}}}
@Composable fun ProfileScreen(onLogout:()->Unit){FormScaffold("Profile & Settings",{onLogout()},"Account"){SummaryCard("User","Sales Executive");SummaryCard("Employee ID","SF0012");Spacer(Modifier.height(10.dp));Text(TAGLINE,color=BrandPurple,fontSize=12.sp);Spacer(Modifier.height(20.dp));Button(onClick=onLogout,Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp)){Text("Logout")}}}

@Composable private fun FormScaffold(title:String,onBack:()->Unit,section:String,content:@Composable ColumnScope.()->Unit){FinanceBackground{Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)){Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Back",tint=BrandNavy)};Column{Text(title,fontSize=25.sp,fontWeight=FontWeight.Bold,color=BrandNavy);Text(TAGLINE,fontSize=10.sp,color=BrandPurple)}};Spacer(Modifier.height(12.dp));Card(shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=Color.White.copy(alpha=.96f))){Column(Modifier.padding(17.dp)){Text(section,fontSize=18.sp,fontWeight=FontWeight.Bold,color=BrandNavy);Spacer(Modifier.height(8.dp));content()}};Spacer(Modifier.height(24.dp))}}}
@Composable private fun SummaryCard(title:String,value:String){Card(Modifier.fillMaxWidth().padding(vertical=4.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White.copy(alpha=.96f))){Row(Modifier.fillMaxWidth().padding(15.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text(title,color=Color(0xFF6D7385),fontSize=13.sp);Text(value,fontWeight=FontWeight.Bold,color=BrandNavy)}}}
@Composable private fun CheckRow(label:String,checked:Boolean,onChecked:(Boolean)->Unit){Row(Modifier.fillMaxWidth().padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically){Checkbox(checked,onChecked);Text(label,color=BrandNavy)}}
@Composable private fun Field(label:String,value:String,onValueChange:(String)->Unit,keyboardType:KeyboardType=KeyboardType.Text,icon:androidx.compose.ui.graphics.vector.ImageVector?=null,password:Boolean=false){OutlinedTextField(value=value,onValueChange=onValueChange,label={Text(label)},singleLine=true,leadingIcon=icon?.let{{Icon(icon,null,tint=BrandPurple)}},visualTransformation=if(password)PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,keyboardOptions=KeyboardOptions(keyboardType=keyboardType),shape=RoundedCornerShape(15.dp),modifier=Modifier.fillMaxWidth().padding(vertical=5.dp),colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=BrandPurple,focusedLabelColor=BrandPurple,unfocusedBorderColor=Color(0xFFD8DCE8)))}
